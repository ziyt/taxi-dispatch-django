from django.apps import AppConfig

class DispatchApiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "dispatch_api"