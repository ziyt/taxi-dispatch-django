from django.apps import AppConfig

class DispatchCoreConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "dispatch_core"